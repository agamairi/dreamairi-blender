"""Core generation pipeline."""
